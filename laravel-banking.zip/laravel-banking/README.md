## Laravel Banking App
A simple bank transaction management system by using laravel.

## Features
- Add Bank
- Make Transaction
- View Statement
- Pie Chart Preview
- CRUD Operations

## Screenshots
![1](https://github.com/masudncse/laravel-banking-app/blob/master/screenshots/1.png)
![2](https://github.com/masudncse/laravel-banking-app/blob/master/screenshots/2.png)
![3](https://github.com/masudncse/laravel-banking-app/blob/master/screenshots/3.png)
